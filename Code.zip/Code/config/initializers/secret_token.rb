# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
FirstApp::Application.config.secret_key_base = '3db796d214943c55d50287674cba372cde38fb516471890a71936e9bd396fa4857c2d70d1ffc82d61f54b0f4d7933a43a673f05380b391f27b8de26463b6425c'
